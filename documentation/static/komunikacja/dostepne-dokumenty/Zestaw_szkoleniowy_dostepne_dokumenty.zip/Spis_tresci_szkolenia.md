# 📚 Zestaw materiałów szkoleniowych „Tworzenie dostępnych dokumentów w praktyce”

## Spis treści

### Moduły dydaktyczne
1. **Moduł 1:** Struktura i formatowanie dokumentu  
2. **Moduł 2:** Treści i elementy wizualne  
3. **Moduł 3:** Łącza, multimedia i końcowa weryfikacja dostępności  

### Mini poradniki
4. Stosowanie nagłówków  
5. Stosowanie list  
6. Stosowanie obrazów  
7. Stosuj tabele do prezentacji danych  
8. Stosowanie linków i przypisów  
9. Używanie kolorów i zachowanie odpowiedniego kontrastu  
10. Audio i wideo oraz ich alternatywy  

### Materiał uzupełniający
11. **Słowa o dostępności cyfrowej** – słownik terminów  

---

Wszystkie materiały opracowano w stylu urzędowym zgodnym z zasadami **WCAG 2.1 poziom AA**.  
Zestaw może być wykorzystywany do celów szkoleniowych i wdrożeniowych w instytucjach publicznych.
