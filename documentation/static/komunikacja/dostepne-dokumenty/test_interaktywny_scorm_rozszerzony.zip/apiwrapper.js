/*
  Minimal SCORM 1.2 API discovery & wrapper (Moodle-ready)
*/
var API = null;
var findTries = 0;

function findAPI(win){
  while ((win.API == null) && (win.parent != null) && (win.parent != win)) {
    findTries++;
    if (findTries > 500) return null;
    win = win.parent;
  }
  return win.API;
}
function getAPI(){
  if (API != null) return API;
  API = findAPI(window);
  if ((API == null) && (window.opener != null) && (typeof(window.opener) != "undefined")) {
    API = findAPI(window.opener);
  }
  return API;
}
function LMSInitialize(param){ var api = getAPI(); return api ? api.LMSInitialize(param) : "true"; }
function LMSFinish(param){ var api = getAPI(); return api ? api.LMSFinish(param) : "true"; }
function LMSGetValue(el){ var api = getAPI(); return api ? api.LMSGetValue(el) : ""; }
function LMSSetValue(el,val){ var api = getAPI(); return api ? api.LMSSetValue(el,val) : "true"; }
function LMSCommit(param){ var api = getAPI(); return api ? api.LMSCommit(param) : "true"; }
function LMSGetLastError(){ var api = getAPI(); return api ? api.LMSGetLastError() : "0"; }
